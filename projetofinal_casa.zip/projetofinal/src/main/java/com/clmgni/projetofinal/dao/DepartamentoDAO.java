package com.clmgni.projetofinal.dao;

import org.springframework.data.repository.CrudRepository;

import com.clmgni.projetofinal.model.departamento;

public interface DepartamentoDAO extends CrudRepository<departamento, Integer> {
	public departamento findByAndarAndNome(int andar, String nome);
	public departamento findByNome(String nome);
}