package com.clmgni.projetofinal.Controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.clmgni.projetofinal.dao.DepartamentoDAO;
import com.clmgni.projetofinal.model.departamento;

@RestController
public class DepartamentoController {

	@Autowired
	private DepartamentoDAO dao;
	
	@GetMapping("/dep")
	public ArrayList<departamento> listarTodos(){
		return (ArrayList<departamento>)dao.findAll();
	}

	@PostMapping("/anddepto")
	public ResponseEntity<departamento> findAndDepto(@RequestBody departamento dadosDepto) {
		departamento res = dao.findByAndarAndNome(dadosDepto.getAndar(),dadosDepto.getNome());
		if (res !=null) { // o usuario existe
			return ResponseEntity.ok(res);
		}
		else {
			return ResponseEntity.status(403).build();
		}
	}	
	@PostMapping("/depto")
	public ResponseEntity<departamento> findDepto(@RequestBody departamento dadosDepto) {
		departamento res = dao.findByNome(dadosDepto.getNome());
		if (res !=null) { // o email existe
			return ResponseEntity.ok(res);
		}
		else {
			return ResponseEntity.status(403).build();
		}
	}	
}


