package com.clmgni.projetofinal.dao;

import org.springframework.data.repository.CrudRepository;

import com.clmgni.projetofinal.model.Usuario;

public interface UsuarioDAO extends CrudRepository<Usuario, Integer> {
	public Usuario findByEmailAndSenha(String email, String senha);
	public Usuario findByEmail(String email);
}
