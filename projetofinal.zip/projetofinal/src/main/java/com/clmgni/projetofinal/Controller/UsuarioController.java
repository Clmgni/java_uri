package com.clmgni.projetofinal.Controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.clmgni.projetofinal.dao.UsuarioDAO;
import com.clmgni.projetofinal.model.Usuario;

@RestController
public class UsuarioController {

	@Autowired
	private UsuarioDAO dao;
	
	@GetMapping("/usuario")
	public ArrayList<Usuario> listarTodos(){
		return (ArrayList<Usuario>)dao.findAll();
	}
	
	@PostMapping("/login")
	public ResponseEntity<Usuario> logarUsuario(@RequestBody Usuario dadosLogin) {
		Usuario res = dao.findByEmailAndSenha(dadosLogin.getEmail(),dadosLogin.getSenha());
		if (res !=null) { // o usuario existe
			if (res.getSenha().equals(dadosLogin.getSenha())) {
				return ResponseEntity.ok(res);
			}
			return ResponseEntity.ok(res);
		}
		else {
			return ResponseEntity.status(403).build();
		}
	}	
}


